package com.testpayusdkmodule;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.payu.india.Model.PaymentParams;

// import com.payu.india.;


public class PayuModule extends ReactContextBaseJavaModule {
//    private final ReactApplicationContext reactContext;
    public PayuModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
//        this.reactContext = reactContext;
        reactApplicationContext.addActivityEventListener(this);
    }

    private static final int PAYUMONEY_RESULT = 0;

    @Override
    public String getName() {
        return "payu";
    }

    @ReactMethod
    public void makePayment(final String key,
                            final String txnId,
                            final String amount,
                            final String firstName,
                            final String email,
                            final String phone,
                            final String productInfo,
                            final String merchantSUrl,
                            final String merchantFUrl,
                            final String hash) {
        ReactApplicationContext context = getReactApplicationContext();
        AppCompatActivity currentActivity = getCurrentActivity();
        Intent intent = new Intent(currentActivity, PayuBaseActivity.class);

        PaymentParams mPaymentParams = new PaymentParams();

        mPaymentParams.setKey(key);
        mPaymentParams.setAmount(amount);
        mPaymentParams.setProductInfo(productInfo);
        mPaymentParams.setFirstName(firstName);
        mPaymentParams.setEmail(email);
        mPaymentParams.setTxnId(phone);
        mPaymentParams.setSurl(merchantSUrl);
        mPaymentParams.setFurl(merchantFUrl);
        // mPaymentParams.setUdf1(“udf1l”);
        // mPaymentParams.setUdf2(“udf2”);
        // mPaymentParams.setUdf3(“udf3”);
        // mPaymentParams.setUdf4(“udf4”);
        // mPaymentParams.setUdf5(“udf5”);
        mPaymentParams.setHash(hash);


        // intent.putExtra("amount", Double.parseDouble(amount));
        // intent.putExtra("txnId", txnId);
        // intent.putExtra("productName", productName);
        // intent.putExtra("firstName", firstName);
        // intent.putExtra("email", email);
        // intent.putExtra("phone", phone);
        // intent.putExtra("merchantId", merchantId);
        // intent.putExtra("merchantKey", merchantKey);
        // intent.putExtra("merchantSUrl", merchantSUrl);
        // intent.putExtra("merchantFUrl", merchantFUrl);
        // intent.putExtra("merchantSandbox", merchantSandbox);
        // intent.putExtra("hash", hash);

        currentActivity.startActivityForResult(intent, PAYUMONEY_RESULT);
    }

    public void onNewIntent(Intent intent) {
    }

    public void onActivityResult(AppCompatActivity activity, int requestCode, int resultCode, Intent data) {
        onActivityResult(requestCode, resultCode, data);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PAYUMONEY_RESULT) {
            Boolean success = data.getBooleanExtra("success", false);
            if (success) {
                String payuResponse = data.getStringExtra("payuResponse");
                sendEvent("PAYU_PAYMENT_SUCCESS", payuResponse);
            } else {
                sendEvent("PAYU_PAYMENT_FAILED", "{error:true}");
            }
        }
    }

    private void sendEvent(String eventName, String params) {
        ReactApplicationContext context = getReactApplicationContext();
        context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, params);
    }

//    @ReactMethod
//    public void sampleMethod(String stringArgument, int numberArgument, Callback callback) {
//        // TODO: Implement some actually useful functionality
//        callback.invoke("Received numberArgument: " + numberArgument + " stringArgument: " + stringArgument);
//    }
}
